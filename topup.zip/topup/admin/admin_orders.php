<?php
// Include the database connection
include '../components/connect.php'; 
// Include the admin header
include '../components/admin_header.php';

// Fetch orders from the database
$query = "SELECT orders.* FROM orders";
$result = mysqli_query($conn, $query);

// Handle order deletion
if (isset($_POST['delete_order'])) {
    $orderId = $_POST['order_id'];

    // Delete query for orders
    $deleteQuery = "DELETE FROM orders WHERE id = $orderId";

    if (mysqli_query($conn, $deleteQuery)) {
        echo "<script>alert('Order deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting order.');</script>";
    }
}

// Handle deleting all orders
if (isset($_POST['delete_all_orders'])) {
    // Delete query for all orders
    $deleteAllQuery = "DELETE FROM orders";

    if (mysqli_query($conn, $deleteAllQuery)) {
        echo "<script>alert('All orders deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting all orders.');</script>";
    }
}

// Handle order status update
if (isset($_POST['update_status'])) {
    $orderId = $_POST['order_id'];
    $newStatus = $_POST['status'];

    // Update query for order status
    $updateQuery = "UPDATE orders SET status = '$newStatus' WHERE id = $orderId";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Order status updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating order status.');</script>";
    }
}

// Handle updating status for all orders
if (isset($_POST['update_all_status'])) {
    $newStatus = $_POST['all_status'];

    // Update query for all orders' status
    $updateAllStatusQuery = "UPDATE orders SET status = '$newStatus'";

    if (mysqli_query($conn, $updateAllStatusQuery)) {
        echo "<script>alert('All order statuses updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating all order statuses.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #a810ee;
            text-align: center;
        }
        .dashboard-container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .orders-table th, .orders-table td {
            border: 1px solid #000;
            padding: 10px;
            text-align: left;
        }
        .orders-table th {
            background-color: #ff5722;
        }
        .btn {
            background-color: #ff5722;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #a810ee;
        }
        .btn-delete {
            background-color: #d9534f; 
        }
        .btn-delete:hover {
            background-color: #a810ee;
        }
        select {
            padding: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .bulk-actions {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
        .bulk-actions button {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <main>
        <div class="dashboard-container">
            <h1>Manage Orders</h1>

            <!-- Bulk actions: Delete all and update all statuses -->
            <div class="bulk-actions">
                <form method="POST">
                    <button type="submit" name="delete_all_orders" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete ALL orders?');">Delete All Orders</button>
                </form>
                <form method="POST">
                    <select name="all_status" required>
                        <option value="" disabled selected>Change Status to...</option>
                        <option value="Pending">Pending</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                    <button type="submit" name="update_all_status" class="btn">Change Status for All Orders</button>
                </form>
            </div>

            <!-- Display orders table -->
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Player Name</th>  <!-- Added Player Name column -->
                        <th>UID</th>           <!-- Added UID column -->
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['player_name']); ?></td>  <!-- Display Player Name -->
                        <td><?php echo htmlspecialchars($row['uid']); ?></td>           <!-- Display UID -->
                        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>Rs <?php echo number_format($row['total_price'], 2); ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="Completed" <?php if ($row['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
                                    <option value="Cancelled" <?php if ($row['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                                </select>
                                <input type="hidden" name="update_status">
                            </form>
                        </td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete_order" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this order?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
