<?php
session_start();
include '../components/connect.php'; 

// Include the admin header
include '../components/admin_header.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php'); 
    exit();
}

// Handle delete admin
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header('Location: admin_admins.php'); 
    exit();
}

// Handle edit admin
if (isset($_POST['edit_id'])) {
    $edit_id = $_POST['edit_id'];
    $new_email = $_POST['email'];

    $stmt = $conn->prepare("UPDATE admins SET email = ? WHERE admin_id = ?");
    $stmt->bind_param("si", $new_email, $edit_id);
    $stmt->execute();
    header('Location: admin_admins.php'); 
    exit();
}

// Fetch all admins from the database
$query = "SELECT * FROM admins ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management</title>
    <link rel="stylesheet" href="/css/admin.css"> 
    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

main {
    padding: 20px;
}

/* Admins Container */
.admins-container {
    max-width: 900px;
    margin: auto;
    background: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #f2f2f2;
}

/* Button Styles */
.btn-edit, .btn-delete {
    padding: 5px 10px;
    border: none;
    border-radius: 3px;
    color: #fff;
    text-decoration: none;
}

.btn-edit {
    background-color: #4CAF50; 
}

.btn-delete {
    background-color: #f44336; 
}

/* Form Styles */
form {
    display: inline;
}

input[type="email"] {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
    width: 200px;
}

input[type="email"]:focus {
    border-color: #4CAF50;
    outline: none;
}

    </style>
</head>
<body>
    <main>
        <div class="admins-container">
            <h1>Manage Admins</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Date Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['admin_id']; ?></td>
                                <td>
                                    <?php if (isset($_GET['edit_id']) && $_GET['edit_id'] == $row['admin_id']): ?>
                                        <form method="POST" action="">
                                            <input type="hidden" name="edit_id" value="<?php echo $row['admin_id']; ?>">
                                            <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
                                            <button type="submit">Save</button>
                                        </form>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($row['email']); ?>
                                        <a href="?edit_id=<?php echo $row['admin_id']; ?>" class="btn-edit">Edit</a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('Y-m-d H:i:s', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <a href="admin_admins.php?delete_id=<?php echo $row['admin_id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this admin?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No admins found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
