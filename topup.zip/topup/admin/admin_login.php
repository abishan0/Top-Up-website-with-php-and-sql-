<?php
session_start();

include '../components/connect.php';

// Check if there's a registration success message
$successMessage = '';
if (isset($_SESSION['register_success'])) {
    $successMessage = $_SESSION['register_success'];
    unset($_SESSION['register_success']); 
}

// Handle login form submission
$errorMessage = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL to fetch admin by email
    $sql = "SELECT * FROM admins WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the admin exists
    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $admin['password'])) {
            // Login successful
            $_SESSION['admin_logged_in'] = true; 
            $_SESSION['admin_id'] = $admin['admin_id']; 
            $_SESSION['admin_email'] = $admin['email']; 
            header("Location: admin_dashboard.php"); 
            exit();
        } else {
            $errorMessage = "Incorrect password.";
        }
    } else {
        $errorMessage = "Admin not found with this email.";
    }

    $stmt->close();
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="/css/admin.css"> 
</head>
<body>
    <div class="container">
        <h2>Admin Login</h2>

        <!-- Success message after registration -->
        <?php if ($successMessage): ?>
            <p class="success"><?php echo htmlspecialchars($successMessage); ?></p>
        <?php endif; ?>

        <!-- Error message if login fails -->
        <?php if ($errorMessage): ?>
            <p class="error"><?php echo htmlspecialchars($errorMessage); ?></p>
        <?php endif; ?>

        <form action="admin_login.php" method="POST">
            <label for="email">Email:</label><br>
            <input type="email" name="email" id="email" required><br><br>

            <label for="password">Password:</label><br>
            <input type="password" name="password" id="password" required><br><br>

            <button type="submit">Login</button>
        </form>

        <br>
        <!-- Links to register page and forgot password -->
        <p>Don't have an account?<a href="admin_register.php"> Register here</a><br></p>
        <a href="admin_forgot_password.php">Forgot password?</a>
    </div>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
