<?php
// Include the database connection
include '../components/connect.php'; 
// Include the admin header
include '../components/admin_header.php';

// Fetch featured products from the database
$query = "SELECT * FROM featured_products";
$result = mysqli_query($conn, $query);

// Handle product update
if (isset($_POST['update_product'])) {
    $productId = $_POST['product_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $stars = $_POST['stars'];

    // Image update logic
    if (!empty($_FILES['image']['name'])) {
        $image = 'uploads/' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], $image);
    } else {
        $image = $_POST['existing_image'];
    }

    // Update query for featured products
    $updateQuery = "UPDATE featured_products SET name = '$name', description = '$description', price = '$price', 
                    category = '$category', stars = '$stars', image = '$image' WHERE id = $productId";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Product updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating product.');</script>";
    }
}

// Handle product deletion
if (isset($_POST['delete_product'])) {
    $productId = $_POST['product_id'];

    // Delete query for featured products
    $deleteQuery = "DELETE FROM featured_products WHERE id = $productId";

    if (mysqli_query($conn, $deleteQuery)) {
        echo "<script>alert('Product deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting product.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Featured Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .dashboard-container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .product-table th, .product-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        .product-table th {
            background-color: #f2f2f2;
        }
        .product-table img {
            max-width: 100px;
        }
        .btn {
            background-color: #ff5722;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #a810ee;
        }
        .btn-update {
            background-color: #4CAF50; 
        }
        .btn-update:hover {
            background-color: #a810ee;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <main>
        <div class="dashboard-container">
            <h1>Manage Featured Products</h1>

            <!-- Display featured products table -->
            <table class="product-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Stars</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><?php echo $row['category']; ?></td>
                        <td><?php echo $row['stars']; ?></td>
                        <td><img src="<?php echo $row['image']; ?>" alt="Product Image"></td>
                        <td>
                            <button class="btn btn-edit" data-product-id="<?php echo $row['id']; ?>">Edit</button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete_product" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this product?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <tr id="edit-section-<?php echo $row['id']; ?>" style="display: none;">
                        <td colspan="8">
                            <form action="" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="existing_image" value="<?php echo $row['image']; ?>">

                                <label for="name">Name:</label>
                                <input type="text" name="name" value="<?php echo $row['name']; ?>" required>

                                <label for="description">Description:</label>
                                <textarea name="description" required><?php echo $row['description']; ?></textarea>

                                <label for="price">Price:</label>
                                <input type="number" step="0.01" name="price" value="<?php echo $row['price']; ?>" required>

                                <label for="category">Category:</label>
                                <input type="text" name="category" value="<?php echo $row['category']; ?>" required>

                                <label for="stars">Stars:</label>
                                <input type="number" step="0.1" min="0" max="5" name="stars" value="<?php echo $row['stars']; ?>" required>

                                <label for="image">Product Image:</label>
                                <input type="file" name="image">
                                <img src="<?php echo $row['image']; ?>" alt="Product Image" width="100">

                                <button type="submit" name="update_product" class="btn btn-update">Update</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        // Toggle edit section display
        const editButtons = document.querySelectorAll('.btn-edit');
        editButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const productId = button.getAttribute('data-product-id');
                const editSection = document.getElementById(`edit-section-${productId}`);
                editSection.style.display = editSection.style.display === 'none' ? 'table-row' : 'none';
            });
        });
    </script>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
