<?php
// Include the database connection
include '../components/connect.php';
// Include the admin header
include '../components/admin_header.php';

// Fetch users from the database
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);

// Handle suspension
if (isset($_POST['suspend'])) {
    $userId = $_POST['user_id'];
    $suspensionDays = $_POST['suspension_days'];

    // Update user suspension status in the database
    $suspensionEndDate = date('Y-m-d H:i:s', strtotime("+$suspensionDays days"));
    $updateQuery = "UPDATE users SET suspension_end_date = '$suspensionEndDate' WHERE user_id = $userId";
    mysqli_query($conn, $updateQuery);
}

// Handle unsuspension
if (isset($_POST['unsuspend'])) {
    $userId = $_POST['user_id'];

    // Clear the suspension end date in the database
    $updateQuery = "UPDATE users SET suspension_end_date = NULL WHERE user_id = $userId";
    mysqli_query($conn, $updateQuery);
}

// Handle update
if (isset($_POST['update_user'])) {
    $userId = $_POST['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
    $address = $_POST['address'];

    // Profile picture upload logic (if needed)
    if (!empty($_FILES['profile_picture']['name'])) {
        $profile_picture = 'uploads/' . $_FILES['profile_picture']['name'];
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture);
    } else {
        $profile_picture = $_POST['existing_profile_picture'];
    }

    // Update query
    $updateQuery = "UPDATE users SET username = '$username', email = '$email', dob = '$dob', 
                    gender = '$gender', phone_number = '$phone_number', address = '$address', 
                    profile_picture = '$profile_picture' WHERE user_id = $userId";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('User information updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating user information.');</script>";
    }
}

// Handle deletion via POST
if (isset($_POST['delete_user'])) {
    $deleteId = $_POST['delete_id'];

    // Check if delete_id is set and valid
    if (empty($deleteId)) {
        echo "<script>alert('No user ID provided for deletion.');</script>";
    } else {
        // First delete the related orders and messages manually
        $deleteOrders = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
        $deleteOrders->bind_param("i", $deleteId);
        $deleteOrders->execute();

        $deleteMessages = $conn->prepare("DELETE FROM messages WHERE user_id = ?");
        $deleteMessages->bind_param("i", $deleteId);
        $deleteMessages->execute();

        // Now delete the user
        $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $deleteId);

        if ($stmt->execute()) {
            // Redirect to the same page after deletion to show updated list
            echo "<script>alert('User deleted successfully!'); window.location.href = 'admin_users.php';</script>";
        } else {
            // Display error with more information
            echo "<script>alert('Error deleting user: " . $conn->error . "');</script>";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="path/to/your/styles.css"> 
</head>
<body>
    <main>
        <div class="dashboard-container">
            <h1>Manage Users</h1>
            <table class="user-table">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td>
                            <a href="#" class="btn btn-edit" data-user-id="<?php echo $row['user_id']; ?>">Edit</a>
                            
                            <!-- Updated Delete Button as Form -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="delete_id" value="<?php echo $row['user_id']; ?>">
                                <button type="submit" name="delete_user" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this user?');">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <tr id="edit-section-<?php echo $row['user_id']; ?>" style="display: none;">
                        <td colspan="4">
                            <form action="" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                <input type="hidden" name="existing_profile_picture" value="<?php echo $row['profile_picture']; ?>">

                                <label for="username">Username:</label>
                                <input type="text" name="username" value="<?php echo $row['username']; ?>" required>

                                <label for="email">Email:</label>
                                <input type="email" name="email" value="<?php echo $row['email']; ?>" required>

                                <label for="dob">Date of Birth:</label>
                                <input type="date" name="dob" value="<?php echo $row['dob']; ?>" required>

                                <label for="gender">Gender:</label>
                                <select name="gender" required>
                                    <option value="male" <?php if ($row['gender'] == 'male') echo 'selected'; ?>>Male</option>
                                    <option value="female" <?php if ($row['gender'] == 'female') echo 'selected'; ?>>Female</option>
                                    <option value="other" <?php if ($row['gender'] == 'other') echo 'selected'; ?>>Other</option>
                                </select>

                                <label for="phone_number">Phone Number:</label>
                                <input type="text" name="phone_number" value="<?php echo $row['phone_number']; ?>">

                                <label for="address">Address:</label>
                                <input type="text" name="address" value="<?php echo $row['address']; ?>">

                                <label for="profile_picture">Profile Picture:</label>
                                <input type="file" name="profile_picture">
                                <img src="<?php echo $row['profile_picture']; ?>" alt="Profile Picture" width="100">

                                <!-- Update Button -->
                                <button type="submit" name="update_user" class="btn btn-update">Update</button>

                                <!-- Suspension / Unsuspension Section -->
                                <?php if (isset($row['suspension_end_date']) && strtotime($row['suspension_end_date']) > time()): ?>
                                    <label>User is currently suspended until <?php echo $row['suspension_end_date']; ?>:</label>
                                    <button type="submit" name="unsuspend" class="btn btn-unsuspend">Unsuspend</button>
                                <?php else: ?>
                                    <label for="suspension_days">Suspend for:</label>
                                    <select name="suspension_days" required>
                                        <?php for ($i = 1; $i <= 365; $i++): ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?> Day(s)</option>
                                        <?php endfor; ?>
                                    </select>
                                    <button type="submit" name="suspend" class="btn btn-suspend">Suspend</button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        // Toggle edit section display
        const editLinks = document.querySelectorAll('.btn-edit');
        editLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const userId = link.getAttribute('data-user-id');
                const editSection = document.getElementById(`edit-section-${userId}`);
                editSection.style.display = editSection.style.display === 'none' ? 'table-row' : 'none';
            });
        });
    </script>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>

