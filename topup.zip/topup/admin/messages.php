<?php
session_start();
include '../components/connect.php'; 

// Include the admin header
include '../components/admin_header.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php'); 
    exit();
}

// Handle delete individual message
if (isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header('Location: messages.php'); 
    exit();
}

// Handle delete all messages
if (isset($_POST['delete_all'])) {
    $stmt = $conn->prepare("DELETE FROM messages");
    $stmt->execute();
    header('Location: messages.php'); 
    exit();
}

// Fetch all messages from the database
$query = "SELECT m.*, u.username FROM messages m INNER JOIN users u ON m.user_id = u.user_id ORDER BY m.created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Messages</title>
    <link rel="stylesheet" href="/css/admin.css"> 
</head>
<body>
    <main>
        <div class="messages-container">
            <h1>User Messages</h1>
            <form method="POST" action="">
                <button type="submit" name="delete_all" class="btn-delete-all">Delete All Messages</button>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Photo</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                                <td>
                                    <?php if ($row['photo']): ?>
                                        <img src="<?php echo $row['photo']; ?>" alt="Attached Photo" width="100">
                                    <?php else: ?>
                                        No photo
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('Y-m-d H:i:s', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this message?');">
                                        <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="btn-delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9">No messages found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
