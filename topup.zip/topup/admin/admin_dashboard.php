<?php
// Include the database connection
include '../components/connect.php'; 
// Include the admin header
include '../components/admin_header.php';

// Initialize counts
$totalUsers = $totalProducts = $totalOrders = $totalAdmins = $totalMessages = 0;
$totalRevenue = $totalProfit = $totalLoss = 0;

// Function to fetch total count from a given table
function fetchTotalCount($conn, $table) {
    $result = $conn->query("SELECT COUNT(*) AS total FROM $table");
    
    // Check if the query was successful and fetch the result
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['total']; // Return the total count
    } else {
        return 0; // Return 0 if the query fails or no rows are found
    }
}

// Fetch counts from the database
$totalUsers = fetchTotalCount($conn, 'users');
$totalProducts = fetchTotalCount($conn, 'products') + fetchTotalCount($conn, 'featured_products');
$totalOrders = fetchTotalCount($conn, 'orders');
$totalMessages = fetchTotalCount($conn, 'messages');
$totalAdmins = fetchTotalCount($conn, 'admins');

// Fetch revenue, profit, and loss
$result = $conn->query("SELECT SUM(total_price) AS revenue, SUM(profit) AS profit FROM orders");
if ($result && $row = $result->fetch_assoc()) {
    $totalRevenue = $row['revenue'] ?? 0;
    $totalProfit = $row['profit'] ?? 0;
}

// Assuming a simple calculation for totalLoss (for example, you can adjust this based on your requirements)
$totalLoss = $totalRevenue - $totalProfit; // You might want to customize this based on your calculations

// Fetch recent activities
$recentActivities = [];
// Uncomment and adjust according to your database structure
// $activityResult = $conn->query("SELECT * FROM activities ORDER BY created_at DESC LIMIT 5");
// if ($activityResult) {
//     while ($activity = $activityResult->fetch_assoc()) {
//         $recentActivities[] = $activity;
//     }
// } else {
//     echo "Failed to fetch recent activities: " . $conn->error;
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="/css/admin.css">
</head>
<body>
    <button class="toggle-button" id="toggleButton">&#9776;</button> <!-- Hamburger icon -->
    <div class="sidebar" id="sidebar">
        <h2>Admin Menu</h2>
        <?php 
        $sidebarItems = [
            ["link" => "admin_users.php", "label" => "User Management"],
            ["link" => "admin_products.php", "label" => "Product Management"],
            ["link" => "admin_orders.php", "label" => "Order Management"],
            ["link" => "admin_admins.php", "label" => "Admin Management"],
            ["link" => "messages.php", "label" => "User Messages"],
            ["link" => "featured_products.php", "label" => "Manage Featured Products"],
            ["link" => "logout.php", "label" => "Logout"],
        ];
        
        foreach ($sidebarItems as $item) {
            echo "<a href='{$item['link']}'>{$item['label']}</a>";
        }
        ?>
        <button id="closeMenuButton" class="close-button" style="display: none; color: #000; font-weight: 600; font-size: 20px; width:250px;">Close Menu</button>
    </div>

    <div class="main-content" id="mainContent">
        <h1>Admin Dashboard</h1>
        <div class="stats-container">
            <a href="admin_users.php" class="stat-box">
                <h2>Total Users</h2>
                <p><?php echo htmlspecialchars($totalUsers); ?></p>
            </a>
            <a href="admin_products.php" class="stat-box">
                <h2>Total Products</h2>
                <p><?php echo htmlspecialchars($totalProducts); ?></p>
            </a>
            <a href="admin_orders.php" class="stat-box">
                <h2>Total Orders</h2>
                <p><?php echo htmlspecialchars($totalOrders); ?></p>
            </a>
            <a href="admin_admins.php" class="stat-box">
                <h2>Total Admins</h2>
                <p><?php echo htmlspecialchars($totalAdmins); ?></p>
            </a>
            <a href="messages.php" class="stat-box">
                <h2>Total Messages</h2>
                <p><?php echo htmlspecialchars($totalMessages); ?></p>
            </a>
            <a href="featured_products.php" class="stat-box">
                <h2>Manage Featured Products</h2>
                <p>Click Here</p>
            </a>
        </div>

        <!-- Revenue, Profit, and Loss Section -->
        <div class="financial-stats">
            <h2>Financial Overview</h2>
            <div class="financial-box">
                <h3>Total Revenue</h3>
                <p><?php echo htmlspecialchars(number_format($totalRevenue, 2)); ?> Rs </p>
            </div>
            <div class="financial-box">
                <h3>Total Profit</h3>
                <p><?php echo htmlspecialchars(number_format($totalProfit, 2)); ?> Rs </p>
            </div>
            <div class="financial-box">
                <h3>Total Loss</h3>
                <p><?php echo htmlspecialchars(number_format($totalLoss, 2)); ?> Rs </p>
            </div>
        </div>

        <!-- Recent Activities Section -->
        <div class="recent-activities">
            <h2>Recent Activities</h2>
            <ul>
                <?php if (!empty($recentActivities)): ?>
                    <?php foreach ($recentActivities as $activity): ?>
                        <li><?php echo htmlspecialchars($activity['description']) . ' - ' . date('F j, Y, g:i a', strtotime($activity['created_at'])); ?></li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li>No recent activities found.</li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Notifications Section -->
        <div class="notifications">
            <h2>Notifications</h2>
            <ul>
                <li>2 new users registered today.</li>
                <li>3 orders are pending shipment.</li>
                <li>You have 5 new messages.</li>
            </ul>
        </div>
    </div>

    <script>
        const toggleButton = document.getElementById('toggleButton');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const closeMenuButton = document.getElementById('closeMenuButton');

        toggleButton.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            mainContent.classList.toggle('expanded');
            toggleButton.innerHTML = sidebar.classList.contains('open') ? '&times;' : '&#9776;'; // Cross or hamburger icon
            closeMenuButton.style.display = sidebar.classList.contains('open') ? 'block' : 'none'; // Show or hide the close button
        });

        closeMenuButton.addEventListener('click', () => {
            sidebar.classList.remove('open');
            mainContent.classList.remove('expanded');
            toggleButton.innerHTML = '&#9776;'; // Reset to hamburger icon
            closeMenuButton.style.display = 'none'; // Hide the close button
        });
    </script>
</body>
</html>
<?php include '../components/admin_footer.php'; ?>
