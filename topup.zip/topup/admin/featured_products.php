<?php
session_start();
include '../components/admin_header.php';

include '../components/connect.php';

// Handle form submission for adding products
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stars = $_POST['stars'];
    $description = $_POST['description'];
    $category = $_POST['category']; 

    // Assuming images are uploaded to a folder named "uploads" in your project directory
    $image = 'uploads/' . basename($_FILES["image"]["name"]);

    // Move uploaded file to the uploads folder
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $image)) {
        // Prepare and bind the SQL statement
        $sql = "INSERT INTO featured_products (name, image, price, stars, description, category) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdiss", $name, $image, $price, $stars, $description, $category); // Bind the category

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Product added successfully!";
            header("Location: featured_products.php"); // Redirect to the same page
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error uploading file.";
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Featured Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }
        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #ff5722;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #a810ee;
        }
        .success-message {
            color: green;
            font-weight: bold;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h2>Add Featured Product</h2>

    <?php if (isset($_SESSION['success_message'])): ?>
        <p class="success-message"><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <form action="featured_products.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="add_product" value="1">

        <label for="name">Product Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="image">Upload Image:</label>
        <input type="file" name="image" id="image" accept="image/*" required>

        <label for="price">Price:</label>
        <input type="number" name="price" id="price">

        <label for="stars">Rating (0-5):</label>
        <input type="number" step="0.1" name="stars" id="stars" min="0" max="5" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="4" required></textarea>

        <label for="category">Category:</label>
        <input type="text" name="category" id="category" required>

        <button type="submit">Add Product</button>
    </form>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
        