<?php
session_start();
include '../components/connect.php'; // Include your database connection

// Include the admin header
include '../components/admin_header.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php'); 
    exit();
}

// Fetch the admin's profile information
$admin_id = $_SESSION['admin_id'];
$stmt = $conn->prepare("SELECT email, password FROM admins WHERE admin_id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Handle password update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the required POST keys are set
    $old_password = isset($_POST['old_password']) ? $_POST['old_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    // Verify old password
    if (password_verify($old_password, $admin['password'])) {
        // Check if new passwords match
        if ($new_password === $confirm_password) {
            $stmt = $conn->prepare("UPDATE admins SET password = ? WHERE admin_id = ?");
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt->bind_param("si", $hashed_password, $admin_id);
            $stmt->execute();
            $success_message = "Password updated successfully.";
        } else {
            $error_message = "New passwords do not match.";
        }
    } else {
        $error_message = "Old password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="/css/admin.css"> <!-- Link to your CSS -->
    <style>
        /* Profile Container */
        .profile-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        /* Form Styles */
        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
        }

        input[type="email"],
        input[type="password"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 20px;
        }

        input[type="email"]:disabled {
            background-color: #f9f9f9;
        }

        input[type="password"]:focus,
        input[type="email"]:focus {
            border-color: #4CAF50;
            outline: none;
        }

        button {
            padding: 10px;
            background-color: #ff5722;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a810ee;
        }

        .success-message {
            color: #4CAF50;
            margin-top: 10px;
        }

        .error-message {
            color: #ff5722;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <main>
        <div class="profile-container">
            <h1>Admin Profile</h1>
            <form method="POST" action="">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" disabled>

                <label for="old_password">Old Password</label>
                <input type="password" id="old_password" name="old_password" required>

                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" required>

                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>

                <button type="submit">Update Password</button>
            </form>
            <?php if (isset($success_message)): ?>
                <p class="success-message"><?php echo $success_message; ?></p>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <p class="error-message"><?php echo $error_message; ?></p>
            <?php endif; ?>
        </div>
    </main>
    <?php include '../components/admin_footer.php'; ?>
</body>
</html>
