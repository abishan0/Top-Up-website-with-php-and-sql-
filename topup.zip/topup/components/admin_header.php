<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
?>

<link rel="stylesheet" href="/css/admin.css">
    <header>
    <div class="header-container">
    <div class="logo">
        <a href="admin_dashboard.php">
            <img src="/images/logo.png" alt="Admin Panel"> <!-- Update with your actual logo file -->
        </a>
    </div>
    <nav>
        <ul>
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="admin_products.php">Products</a></li>
            <li><a href="admin_orders.php">Orders</a></li>
            <li><a href="admin_profile.php">Profile</a></li>
            <li><a href="messages.php">Message</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </nav>
</div>

    </header>
