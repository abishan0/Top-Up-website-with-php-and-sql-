<?php
  $server="localhost:3307";
  $userid="root";
  $pwd="abishan";
  $dbname="topup";
  $conn = mysqli_connect($server, $userid, $pwd, $dbname);
//Check connection
if (!$conn) 
  	die("Connection Error: " . mysqli_connect_error());
?>