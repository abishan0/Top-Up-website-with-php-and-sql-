<?php
// Check if a session has been started to ensure proper functionality across admin pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<style>
    .admin-footer {
        background-color: #f4f4f4;
        padding: 20px;
        text-align: center;
    }

    .admin-footer p {
        font-size: 14px;
        color: #555;
        margin: 0;
        
    }

    /* Scroll to top button */
    .scroll-to-top {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #ff5722;
        color: white;
        padding: 10px 15px;
        border-radius: 50%;
        cursor: pointer;
        display: none; /* Hidden by default */
    }

    .scroll-to-top:hover {
        background-color: #a810ee;
    }
</style>

<footer class="admin-footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> All In One. All Rights Reserved.</p>
    </div>
</footer>

<!-- Scroll to top button -->
<div class="scroll-to-top">↑</div>

<script>
    // Show scroll to top button when user scrolls down
    window.addEventListener('scroll', function() {
        const scrollButton = document.querySelector('.scroll-to-top');
        if (window.pageYOffset > 10) {
            scrollButton.style.display = 'block';
        } else {
            scrollButton.style.display = 'none';
        }
    });

    // Scroll to top functionality
    document.querySelector('.scroll-to-top').addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
</script>
