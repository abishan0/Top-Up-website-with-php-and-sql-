<footer>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <div class="container">
        <!-- About Us Section -->
        <div class="footer-section about-us">
            <h3>About Us</h3>
            <p>We are dedicated to providing the best products and services, with a focus on quality and customer satisfaction.</p>
            <a href="about.php" class="learn-more">Learn More</a>
        </div>
        <!-- Quick Links Section -->
        <div class="footer-section quick-links">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="privacy.php">Privacy Policy</a></li>
                <li><a href="terms.php">Terms & Conditions</a></li>
            </ul>
        </div>
        <!-- Follow Us Section -->
        <div class="footer-section follow-us">
            <h3 id="follow">Follow Us</h3>
            <div class="social-icons">
                <a href="https://facebook.com" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://linkedin.com" target="_blank" class="linkedin"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
        <!-- Newsletter Section -->
        <div class="footer-section newsletter">
            <h3>Newsletter</h3>
            <p>Subscribe to our newsletter for the latest updates.</p>
            <form id="newsletter-form" class="newsletter-form" action="#" method="POST">
                <input type="email" id="email" name="email" placeholder="Your email" required>
                <button type="submit">Subscribe</button>
            </form>
            <!-- Message placeholders -->
            <div id="subscribe-message" style="margin-top: 10px;"></div>
        </div>
        <!-- Contact Section -->
        <div class="footer-section contact-us">
            <h3>Contact Us</h3>
            <p>If you have any questions or concerns, please reach out:</p>
            <p><strong>Email:</strong> <a href="mailto:support@allinone.com">support@allinone.com</a></p>
            <p><strong>Phone:</strong> <a href="tel:+977 9745960180">+977 9745960180</a></p>
            <p><strong>Mailing Address:</strong> 1234 Privacy St, Data City, USA</p>
        </div>
    </div>
    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <p>&copy; <?php echo date("Y"); ?> All In One. All rights reserved.</p>
    </div>
</footer>

<!-- Scroll to top button -->
<div class="scroll-to-top">↑</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const footerSections = document.querySelectorAll('.footer-section');
        footerSections.forEach((section, index) => {
            setTimeout(() => {
                section.classList.add('visible');
            }, index * 200); // Stagger the animations
        });
    });

    // Show scroll to top button when user scrolls down
    window.addEventListener('scroll', function() {
        const scrollButton = document.querySelector('.scroll-to-top');
        if (window.pageYOffset > 10) {
            scrollButton.style.display = 'block';
        } else {
            scrollButton.style.display = 'none';
        }
    });

    // Scroll to top functionality
    document.querySelector('.scroll-to-top').addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Handle newsletter subscription
    document.getElementById('newsletter-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        const emailInput = document.getElementById('email');
        const subscribeMessage = document.getElementById('subscribe-message');

        // Validate if the email is a Gmail address
        const isValidGmail = /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(emailInput.value);
        if (isValidGmail) {
            subscribeMessage.innerHTML = '<span style="color: green;">Thank you for subscribing!</span>';
            emailInput.value = ''; // Clear the input field
        } else {
            subscribeMessage.innerHTML = '<span style="color: red;">Please enter a valid Gmail address.</span>';
        }
    });
</script>
