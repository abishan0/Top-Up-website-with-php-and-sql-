<?php
// Start session to track user login status, but only if one hasn't been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
?>
<link rel="stylesheet" href="/css/style.css">
<header>
    <div class="container">
        <div class="logo">
            <a href="index.php">
                <img src="/images/logo.png" alt="Website Logo"> <!-- Website logo -->
            </a>
        </div>
        
        <div class="right-group">
            <nav>
                <ul class="nav-list">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="order.php">Order</a></li>
                    <li><a href="cart.php">Cart</a></li>
                </ul>
            </nav>
            
            <div class="user-actions">
                <?php if ($isLoggedIn): ?>
                    <a href="profile.php">Profile</a>
                <?php else: ?>
                    <a href="login.php">Login In</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

