<?php
// Start the session to manage user login
session_start();

// Include the header file
include '../components/user_header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your CSS file -->
    <title>Terms and Conditions - All In One</title>
    <style>
        .terms-section {
    max-width: 800px; /* Set maximum width for the section */
    margin: 0 auto; /* Center the section */
    padding: 20px; /* Add padding for spacing */
    background-color: #ffffff; /* White background */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

h1 {
    font-size: 2.5em; /* Font size for the heading */
    color: #a810ee; /* Color for the main title */
    text-align: center; /* Center the heading */
    margin-bottom: 20px; /* Space below the heading */
}

p {
    font-size: 1.1em; /* Font size for paragraphs */
    line-height: 1.6; /* Improved line spacing for readability */
    color: #333; /* Dark gray text color */
    margin-bottom: 15px; /* Space between paragraphs */
}

a {
    color: #e60000; /* Link color */
    text-decoration: none; /* Remove underline from links */
    font-weight: bold; /* Bold text for links */
}

a:hover {
    text-decoration: underline; /* Underline effect on hover */
}
    </style>
</head>
<body>

    <main>
    <section class="terms-section">
    <h1>Terms and Conditions</h1>
    <p>Welcome to **All In One**. Your access to and use of our website are conditioned on your acceptance of and compliance with these terms and conditions. These terms apply to all visitors, users, and others who access or use the website. By accessing or using the website, you agree to be bound by these terms. If you disagree with any part of the terms, then you do not have permission to access the website. We encourage all users to carefully read and familiarize themselves with these terms to ensure a clear understanding of their implications before engaging with our services.</p>

    <p>Our website is designed to provide a convenient platform for purchasing gaming-related products and services. We understand that the gaming community is diverse and dynamic, and we strive to cater to the varying needs of our users. As part of this platform, we aim to ensure that our users have a seamless and satisfactory experience while shopping for their favorite gaming items. To achieve this, we may implement various features, functionalities, and policies to protect both our users and our business. It is essential to read and understand these terms, as they outline your rights and responsibilities when using our services. Our goal is to create an environment where users feel confident and secure in their transactions.</p>

    <p>By using our website, you affirm that you are at least 18 years old, or you are accessing the website under the supervision of a parent or guardian. This age requirement is in place to ensure that our services are used responsibly and appropriately. You are responsible for maintaining the confidentiality of your account details, including your username and password, and for all activities that occur under your account. It is crucial to take the necessary precautions to safeguard your account information. If you become aware of any unauthorized use of your account or any other breach of security, you must notify us immediately. We will not be liable for any loss or damage arising from your failure to comply with this obligation. We recommend regularly updating your password and using unique login credentials to enhance your account security.</p>

    <p>**All In One** reserves the right to modify or terminate the website or services at any time without notice. This includes making changes to the website's functionality, features, and available services. We may also change these terms from time to time to reflect updates in our policies or regulatory requirements, and we will notify you of any changes by posting the new terms on our website. It is your responsibility to review these terms periodically for updates, as your continued use of the website following the posting of changes constitutes your acceptance of such changes. We encourage users to stay informed about our terms and any modifications that may impact their use of our services.</p>

    <p>We strive to provide accurate product descriptions, pricing, and availability information. However, we cannot guarantee that all information on the website is complete or error-free, as product information is subject to change. In the event of an error, we reserve the right to correct it and update information on the website, including pricing and availability. We may also refuse or cancel any order placed based on incorrect pricing or availability information. If an order is canceled due to such discrepancies, we will issue a full refund for any payments made. Users are encouraged to double-check product details and prices before finalizing their purchases to ensure they are fully informed.</p>

    <p>Our website may contain links to third-party websites that are not owned or controlled by **All In One**. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party websites. By using our website, you acknowledge and agree that **All In One** shall not be liable for any damages or losses caused by your use of any third-party website. We encourage you to read the terms and conditions and privacy policies of any third-party websites that you visit. This caution is especially important, as third-party sites may have different standards and practices regarding user data and transactions.</p>

    <p>As part of your interaction with us, you may have the opportunity to provide feedback, suggestions, or ideas regarding our products and services. We value your opinions and believe that user input is essential for improving our offerings. By submitting such feedback, you grant us the right to use, modify, and publish your feedback without any obligation to you. We appreciate your input and strive to use it to enhance our offerings. However, please refrain from submitting confidential or proprietary information, as we cannot guarantee the protection of such details. Your contributions are vital in helping us create a better shopping experience for all users.</p>

    <p>We take the protection of your personal information seriously and have implemented various measures to ensure its security. We utilize industry-standard encryption and security protocols to safeguard your data during transactions and storage. For detailed information about how we collect, use, and protect your personal data, please refer to our Privacy Policy. By using our website, you acknowledge that you have read and understood our Privacy Policy and consent to the collection and use of your personal information as described therein. Your trust is paramount, and we are committed to maintaining the confidentiality and security of your information.</p>

    <p>If you have any questions or concerns regarding these terms and conditions, or if you wish to report any violations, please contact us through our <a href="contact.php">Contact Us</a> page. We value your input and are committed to addressing any issues that may arise. Your satisfaction is important to us, and we will work diligently to resolve any concerns you may have. Our dedicated support team is always ready to assist you, ensuring that you have a positive experience while using our website.</p>

    <p>These terms and conditions, together with our Privacy Policy, constitute the entire agreement between you and **All In One** concerning your use of the website. Any failure by us to enforce any right or provision of these terms shall not be deemed a waiver of such right or provision. If any provision of these terms is found to be invalid or unenforceable, the remaining provisions of the terms shall remain in effect. Thank you for choosing **All In One**. We look forward to serving you! Your participation in our community is greatly appreciated, and we are excited to help you explore our gaming products and services.</p>
</section>

    </main>

    <?php include '../components/user_footer.php'; ?>
</body>
</html>
