<?php
session_start(); // Start the session to track cart items

// Include the database connection
include '../components/connect.php'; 

// Include the user header
include '../components/user_header.php'; 


// Initialize the cart if it's not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle adding to the cart
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];

    // Ensure $_SESSION['cart'][$product_id] is an array or not set
    if (isset($_SESSION['cart'][$product_id]) && is_array($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    } else {
        // Fetch the product details from the database
        $query = "SELECT * FROM featured_products WHERE id = $product_id";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $product = mysqli_fetch_assoc($result);

            // Add the product to the cart
            $_SESSION['cart'][$product_id] = [
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1,
                'image' => $product['image']
            ];
        }
    }

    // Redirect to the cart page after adding to the cart
    header('Location: cart.php');
    exit(); // Make sure to exit
}

// Handle removing from the cart
if (isset($_POST['remove_from_cart'])) {
    $product_id = $_POST['remove_from_cart'];
    unset($_SESSION['cart'][$product_id]);

    // Redirect to shop page if cart becomes empty after removal
    if (empty($_SESSION['cart'])) {
        header('Location: shop.php'); // Adjust the path to your shop page if necessary
        exit();
    }
}

// Handle updating quantities
if (isset($_POST['update_cart']) && !empty($_POST['quantities'])) {
    foreach ($_POST['quantities'] as $product_id => $quantity) {
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$product_id]);
        } else {
            // Ensure the cart item is an array before accessing it
            if (isset($_SESSION['cart'][$product_id]) && is_array($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            }
        }
    }

    // Redirect to shop page if cart becomes empty after update
    if (empty($_SESSION['cart'])) {
        header('Location: shop.php'); // Adjust the path to your shop page if necessary
        exit();
    }
}

// Calculate total price
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    if (is_array($item)) { // Ensure that $item is an array
        $total_price += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - All In One</title>
    <link rel="stylesheet" href="path/to/your/styles.css"> <!-- Link to your CSS -->
</head>
<body>
    <main>
        <div class="cart-container">
            <h1>Your Shopping Cart</h1>

            <form action="cart.php" method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
    <?php if (is_array($item)): ?> <!-- Check if $item is an array -->
        <tr>
            <td><img src="<?php echo $item['image']; ?>" alt="Product Image"><?php echo $item['name']; ?></td> <!-- Make sure this is the correct key -->
            <td>Rs <?php echo number_format($item['price'], 2); ?></td>
            <td>
                <input type="number" name="quantities[<?php echo $product_id; ?>]" value="<?php echo $item['quantity']; ?>" min="1">
            </td>
            <td>Rs <?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
            <td>
                <button type="submit" name="remove_from_cart" value="<?php echo $product_id; ?>">Remove</button>
            </td>
        </tr>
    <?php endif; ?>
<?php endforeach; ?>

                    </tbody>
                </table>

                <div class="cart-actions">
                    <p>Total Price: Rs <?php echo number_format($total_price, 2); ?></p>
                    <button id="uc" type="submit" name="update_cart">Update Cart</button>
                    <a href="shop.php" class="btn btn-continue">Continue Shopping</a>
                    <a href="checkout.php" class="btn btn-checkout">Proceed to Checkout</a>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
