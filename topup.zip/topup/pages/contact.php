<?php
session_start();
include '../components/connect.php'; // Include your database connection

// Include the header file
include '../components/user_header.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Handle image upload
    $photo = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $upload_dir = '../uploads/'; // Directory for image uploads
        
        // Ensure the directory exists
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Create the directory if it doesn't exist
        }

        $photo_name = basename($_FILES['photo']['name']);
        $target_file = $upload_dir . $photo_name;

        // Validate the file type
        $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($image_file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                $photo = $target_file;
            } else {
                echo "Error uploading the file.";
            }
        } else {
            echo "Only JPG, JPEG, PNG & GIF files are allowed.";
        }
    }

    // Insert message into the database
    $query = "INSERT INTO messages (user_id, name, email, subject, message, photo) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssss", $user_id, $name, $email, $subject, $message, $photo);
    $stmt->execute();

    // Redirect to a thank you page or display a success message
    echo "Your message has been sent successfully!";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your CSS -->
    <style>
        main {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* Container for the contact form */
.contact-container {
    background-color: #fff;
    padding: 20px 40px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    width: 100%;
}

/* Heading */
.contact-container h1 {
    text-align: center;
    margin-bottom: 20px;
    color: #a810ee;
}

/* Form labels */
.contact-container label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
}

/* Form inputs */
.contact-container input[type="text"],
.contact-container input[type="email"],
.contact-container textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    font-size: 16px;
}

/* File input */
.contact-container input[type="file"] {
    margin-bottom: 20px;
}

/* Button styling */
.contact-container button[type="submit"] {
    background-color: #ff5722;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s ease;
}

/* Button hover effect */
.contact-container button[type="submit"]:hover {
    background-color: #a810ee;
}

    </style>
</head>
<body>
    <main>
        <div class="contact-container">
            <h1>Contact Us</h1>
            <form action="contact.php" method="POST" enctype="multipart/form-data">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" required>

                <label for="message">Message</label>
                <textarea id="message" name="message" rows="5" required></textarea>

                <label for="photo">Upload Image (optional)</label>
                <input type="file" id="photo" name="photo" accept="image/*">

                <button type="submit">Send Message</button>
            </form>
        </div>
    </main>
    <?php include '../components/user_footer.php'; ?>
</body>
</html>
