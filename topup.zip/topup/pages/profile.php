<?php
// Start the session
session_start();

// Include the header file
include '../components/user_header.php';

// Sample connection to the database (replace with your actual DB credentials)
$servername = "localhost:3307";
$username = "root";
$password = "abishan";
$dbname = "topup";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize user variable
$user = [];
$message = '';

// Fetch user details (assuming user ID is stored in session)
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Prepare and execute the SQL statement
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);

    // Check if the statement preparation was successful
    if ($stmt) {
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if user exists
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
        } else {
            echo "User not found.";
        }

        // Close the statement
        $stmt->close();
    } else {
        die("MySQL prepare error: " . $conn->error);
    }
} else {
    echo "User ID is not set.";
}

// Check if the user is suspended
if (isset($user['suspension_end_date']) && strtotime($user['suspension_end_date']) > time()) {
    // Format the suspension end date as Y-M-D
    $suspensionEndDate = date('Y-m-d', strtotime($user['suspension_end_date']));
    
    // Calculate suspension days left
    $suspensionDaysLeft = ceil((strtotime($user['suspension_end_date']) - time()) / (60 * 60 * 24));
    
    echo "<div class='suspension-message'>
    Your account is suspended until $suspensionEndDate. Days left: $suspensionDaysLeft. 
    <a href='your_contact_us_url_here' style='color: green; font-weight: bold; text-decoration: underline;'>Contact Us</a>
</div>";

} else {
    echo "<div class='suspension-message active-message'>Your account is active.</div>";
}


// Check if there's a message set in the session for profile updates
if (isset($_SESSION['profile_update_message'])) {
    $message = $_SESSION['profile_update_message'];
    unset($_SESSION['profile_update_message']); // Clear the message after displaying
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <a href=""></a>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your main CSS file -->
    <title> Profile - All In One</title>
    <style>
        .success {
            color: green; /* Green for success messages */
            text-align: center; /* Center the success message */
            margin-bottom: 20px; /* Space below the message */
        }

        .error {
            color: red; /* Red for error messages */
            text-align: center; /* Center the error message */
            margin-bottom: 20px; /* Space below the message */
        }

    </style>
</head>
<body>
    <main>
        <div class="profile-container">
            <div class="profile-header">
                <!-- Profile Picture -->
                <?php if (!empty($user['profile_picture'])): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" class="profile-pic">
                <?php else: ?>
                    <img src="/images/default_profile.png" alt="Default Profile Picture" class="profile-pic">
                <?php endif; ?>

                <h1>Welcome, <?php echo htmlspecialchars($user['username'] ?? 'Guest'); ?>!</h1>
            </div>

            <!-- Success/Error Message -->
            <?php if ($message): ?>
                <p class="success"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>

            <h2>Profile Information</h2>
            <p><strong>User Name:</strong> <?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></p>
            <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($user['phone_number'] ?? 'N/A'); ?></p>
            <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($user['dob'] ?? 'N/A'); ?></p>
            <p><strong>Gender:</strong> <?php echo htmlspecialchars($user['gender'] ?? 'N/A'); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address'] ?? 'N/A'); ?></p>
            <p><strong>Account Created On:</strong> <?php echo htmlspecialchars($user['created_at'] ?? 'N/A'); ?></p>

                    <!-- Logout Button at the Bottom -->
                    <div class="profile-actions">
                <form action="logout.php" method="POST">    
                    <button type="submit" class="btn">Logout</button>
                </form>
            </div>

            <div class="profile-actions">
                <h3>Account Actions</h3>
                <ul>
                    <li><a href="edit_profile.php" class="btn">Edit Profile</a></li>
                    <li><a href="change_password.php" class="btn">Change Password</a></li>
                    <!-- <li><a href="order_history.php" class="btn">View Order History</a></li> -->
                </ul>
            </div>
        </div>
    </main>

    <?php include '../components/user_footer.php'; ?>
</body>
</html>
