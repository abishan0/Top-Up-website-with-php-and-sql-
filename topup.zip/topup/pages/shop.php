<?php
// Include the database connection
include '../components/connect.php'; // Ensure this points to your database connection file
// Include the user header
include '../components/user_header.php'; 

// Fetch all featured products from the database
$query = "SELECT * FROM featured_products"; // Adjust if necessary
$result = mysqli_query($conn, $query);

// Check for query errors
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - All In One</title>
    <link rel="stylesheet" href="path/to/your/styles.css"> <!-- Link to your CSS -->
    <style>
        /* Internal CSS for the Games section */
        .games-container {
            margin: 40px 0;
            text-align: center;
        }
        .games-container h1 {
            color: #a810ee; /* Color for the heading */
            /* font-size: 36px; */
            margin-bottom: 20px;
        }
        .games-grid {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 0 -10px; /* Adjust spacing */
        }
        .games-grid a {
            text-decoration: none;
            color: #333; /* Default text color */
            width: 30%; /* Adjust width to fit in rows */
            margin: 10px; /* Space between items */
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .games-grid a:hover {
            transform: scale(1.05); /* Scale effect on hover */
        }
        .games-grid img {
            width: 100%;
            height: auto;
            border-bottom: 2px solid #ff5722; /* Border below the image */
        }
        .games-grid h2 {
            padding: 10px;
            background-color: #f9f9f9; /* Background color for title */
            text-align: center;
            margin: 0;
        }
    </style>
</head>
<body>
    <main>
        <div class="shop-container">
            <h1>Shop</h1>
            
            <h2>Featured Products</h2>
            <div class="product-grid">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="product-card">
                        <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Product Image">
                        <h2><?php echo htmlspecialchars($row['name']); ?></h2>
                        
                        <!-- Display Product Description -->
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                        
                        <!-- Display Price -->
                        <p>Price: Rs <?php echo number_format($row['price'], 2); ?></p>
                        
                        <!-- Display Star Ratings -->
                        <p class="rating">Rating: 
                            <?php
                            $fullStars = floor($row['stars']); // Full stars
                            $halfStar = ($row['stars'] - $fullStars) >= 0.5; // Check for half star
                            
                            // Display full stars
                            echo str_repeat('⭐', $fullStars);
                            
                            // Display half star if applicable
                            if ($halfStar) {
                                echo '⭐️'; // Use half-star symbol if applicable
                            }
                            ?>
                            / 5
                        </p>

                        <!-- Add to Cart Button -->
                        <form action="cart.php" method="POST">
                            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="add_to_cart" class="btn btn-add-to-cart">Add to Cart</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>

            <div class="games-container">
                <h1>Games</h1>
                <div class="games-grid">
                    <a href="category_freefire.php">
                        <img src="/images/a1.jpg" alt="Slider Game 1">
                        <h2>Free Fire</h2>
                    </a>
                    <a href="category_pubg.php">
                        <img src="/images/a2.jpeg" alt="Slider Game 2">
                        <h2>PUBG</h2>
                    </a>
                    <a href="category_clashofclan.php">
                        <img src="/images/a3.jpg" alt="Slider Game 3">
                        <h2>Clash of Clan</h2>
                    </a>
                </div>
            </div>
        </div>
    </main>
    <?php include '../components/user_footer.php' ?>
</body>
</html>
