<?php
// Include the header
include '../components/user_header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .about-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 40px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #a810ee;
            text-align: center;
            font-size: 36px;
            margin-bottom: 30px;
            text-transform: uppercase;
        }
        p {
            color: #555;
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
        }
        .vision, .mission, .values, .history, .team, .testimonials {
            margin-top: 50px;
        }
        h2 {
            color: #ff5722;
            font-size: 28px;
            margin-bottom: 20px;
        }
        .values p, .history p, .mission p {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .values p::before, .history p::before, .mission p::before {
            content: '\2022';
            position: absolute;
            left: 0;
            color: #ff5722;
            font-size: 20px;
        }
        .team-members {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .team-member {
            width: 30%;
            text-align: center;
            margin-bottom: 40px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .team-member:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        .team-member img {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            margin-bottom: 15px;
        }
        .team-member h3 {
            color: #333;
            margin: 10px 0 5px;
            font-size: 20px;
        }
        .team-member p {
            color: #888;
            font-size: 14px;
        }
        .testimonials {
            text-align: center;
        }
        .testimonial {
            display: inline-block;
            background-color: #f9f9f9;
            padding: 20px;
            margin: 10px;
            border-radius: 10px;
            max-width: 300px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .testimonial:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        .testimonial p {
            font-style: italic;
            font-size: 14px;
        }
        .testimonial h3 {
            color: #a810ee;
            font-size: 18px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="about-container">
        <h1>About Us</h1>
        <p>
            Welcome to All In One! We are passionate about providing the best shopping experience for digital game products. Our team is committed to delivering high-quality products, seamless transactions, and excellent customer support.
        </p>

        <div class="vision">
            <h2>Our Vision</h2>
            <p>
                To lead the digital game marketplace with innovative solutions and excellent services that meet the needs of gamers worldwide.
            </p>
        </div>

        <div class="mission">
            <h2>Our Mission</h2>
            <p>
                Our mission is to create an easy-to-use platform where customers can find the best digital game products, fast, and secure.
            </p>
            <p>
                We strive to exceed customer expectations by offering diverse products, transparent pricing, and an exceptional support system.
            </p>
        </div>

        <div class="values">
            <h2>Core Values</h2>
            <p>Customer First: We prioritize the satisfaction and needs of our customers.</p>
            <p>Innovation: We embrace technology to continually improve our products and services.</p>
            <p>Integrity: We conduct our business with the highest standards of honesty and fairness.</p>
        </div>

        <div class="history">
            <h2>Our History</h2>
            <p>
                Founded in 2020, All In One began as a small startup focused on offering digital game products for casual and professional gamers alike.
            </p>
            <p>
                Over the years, we have grown exponentially, adding more products and expanding our customer base worldwide.
            </p>
        </div>

        <div class="team">
            <h2>Meet Our Team</h2>
            <div class="team-members">
                <div class="team-member">
                    <img src="/pages/uploads/abi.jpg" alt="Team Member 1">
                    <h3>Abishan Mainali</h3>
                    <p>Founder & CEO</p>
                </div>
                <div class="team-member">
                    <img src="/pages/uploads/kris.jpg" alt="Team Member 2">
                    <h3>Rohit Mainali</h3>
                    <p>Head of Operations</p>
                </div>
                <div class="team-member">
                    <img src="/pages/uploads/nis.jpg" alt="Team Member 3">
                    <h3>Nishan Mainali</h3>
                    <p>Customer Support Manager</p>
                </div>
            </div>
        </div>

        <div class="testimonials">
            <h2>What Our Customers Say</h2>
            <div class="testimonial">
                <p>"All In One offers the best customer service! The product quality is unmatched."</p>
                <h3>-  Ganga Mainali.</h3>
            </div>
            <div class="testimonial">
                <p>"I found exactly what I was looking for. Easy navigation and fast delivery!"</p>
                <h3>- Dikshya Shrestha.</h3>
            </div>
            <div class="testimonial">
                <p>"Excellent service and affordable prices. I highly recommend this platform to any gamer."</p>
                <h3>- Aayusha Bhujel.</h3>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Include the footer
include '../components/user_footer.php';
?>
