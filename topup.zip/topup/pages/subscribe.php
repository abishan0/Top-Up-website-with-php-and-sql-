<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the POST request and sanitize it
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);

    // Validate the email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Invalid email format
        echo '<div class="message error">Invalid email format. Please check it.</div>';
        exit; // Stop script execution if email is invalid
    }

    // Check if the email is a Gmail address
    if (!endsWith($email, '@gmail.com')) {
        echo "Only Gmail addresses are allowed.";
        exit; // Stop script execution if email is not a Gmail address
    }

    // Optional: Check if the email contains common typos
    $commonMistakes = ['@gmial.com', '@hotmail.con', '@yahoo.con']; // Add any common mistakes
    foreach ($commonMistakes as $mistake) {
        if (strpos($email, $mistake) !== false) {
            echo "It seems like you made a typo in your email. Please check it.";
            exit;
        }
    }

    // TODO: Here you can add code to store the email in your database or send a confirmation email

    // Respond to the user
    echo '<div class="message success">Thank you for subscribing to our newsletter!</div>';
}

// Helper function to check if a string ends with a specific substring
function endsWith($haystack, $needle) {
    $length = strlen($needle);  
    return $length > 0 && substr($haystack, -$length) === $needle;
}
?>
