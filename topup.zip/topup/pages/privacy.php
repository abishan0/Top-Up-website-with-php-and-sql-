<?php
// Include the user header
include '../components/user_header.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - All In One</title>
    <link rel="stylesheet" href="/css/styles.css"> <!-- Link to your CSS -->
    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    background-color: #f9f9f9;
    padding: 20px;
}

h1, h2 {
    color: #a810ee;
}

.privacy-container {
    max-width: 800px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    opacity: 0;
    transform: translateY(50px);
    animation: fadeInUp 1s forwards;
}

/* Section Animations */
.policy-section {
    margin-bottom: 40px;
    opacity: 0;
    transform: translateY(30px);
}

.policy-section h2 {
    color: #a810ee;
    font-size: 24px;
    margin-bottom: 10px;
    animation: slideInLeft 0.7s ease-out;
}

.policy-section p, .policy-section ul {
    font-size: 16px;
    color: #555;
    animation: fadeIn 0.7s ease-out;
}

.policy-section ul {
    padding-left: 20px;
    list-style: disc;
}

#cont{
    color: #a810ee;
    text-decoration: underline;
}

/* Keyframe Animations */
@keyframes fadeIn {
    0% {
        opacity: 0;
    }
    100% {
        opacity: 1;
    }
}

@keyframes fadeInUp {
    0% {
        opacity: 0;
        transform: translateY(50px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideInLeft {
    0% {
        opacity: 0;
        transform: translateX(-100px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes slideInRight {
    0% {
        opacity: 0;
        transform: translateX(100px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

/* Button Animation */
button {
    padding: 10px 20px;
    background-color: #ff5722;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: #a810ee;
}

/* Fade-in animation for Contact section */
.policy-section.contact {
    animation: fadeInContact 1s ease-in-out;
}

@keyframes fadeInContact {
    0% {
        opacity: 0;
        transform: scale(0.9);
    }
    100% {
        opacity: 1;
        transform: scale(1);
    }
}

    </style>
</head>
<body>
    <main>
        <div class="privacy-container">
            <h1>Privacy Policy</h1>

            <!-- Introduction Section -->
            <section class="policy-section">
                <h2>Introduction</h2>
                <p>
                    At All In One, your privacy is of utmost importance to us. This Privacy Policy describes how we collect, use, and protect your personal information when you visit and interact with our website. By using our site, you consent to the practices outlined in this policy.
                </p>
                <p>
                    Please take a moment to familiarize yourself with our privacy practices and contact us if you have any questions. Our goal is to be transparent about how we handle your data and ensure that you feel confident in the security of your information.
                </p>
            </section>

            <!-- Information We Collect -->
            <section class="policy-section">
                <h2>Information We Collect</h2>
                <p>We collect both personal and non-personal information from our users, including:</p>
                <ul>
                    <li><strong>Personal Information:</strong> This includes details that can identify you as an individual, such as your name, email address, billing information (including payment details), and other contact information.</li>
                    <li><strong>Non-Personal Information:</strong> This includes anonymous information like your IP address, browser type, referring website, pages visited, and the date and time of each visit.</li>
                </ul>
                <p>
                    This information is gathered through various means, including but not limited to, account registration, order placement, subscription to newsletters, and contact forms.
                </p>
            </section>

            <!-- How We Use Your Information -->
            <section class="policy-section">
                <h2>How We Use Your Information</h2>
                <p>We use the information we collect for a variety of purposes, such as:</p>
                <ul>
                    <li>To process your transactions and fulfill your orders.</li>
                    <li>To personalize your experience on our website.</li>
                    <li>To improve customer service and support by responding to your requests and addressing any issues.</li>
                    <li>To send periodic emails regarding your order, services, or other products.</li>
                    <li>To enhance the functionality and usability of our site based on user feedback.</li>
                    <li>To analyze trends and website usage for internal reporting and improvement purposes.</li>
                    <li>To ensure compliance with legal obligations and safeguard the rights and safety of our users.</li>
                    <li>To protect against fraud, detect suspicious activity, and prevent security breaches.</li>
                </ul>
            </section>

            <!-- Legal Basis for Processing Personal Data (GDPR Compliance) -->
            <section class="policy-section">
                <h2>Legal Basis for Processing Personal Data (GDPR Compliance)</h2>
                <p>
                    If you are a resident of the European Economic Area (EEA), we rely on the following legal bases to process your personal data:
                </p>
                <ul>
                    <li><strong>Consent:</strong> We may process your data if you have given explicit consent for a specific purpose (e.g., subscribing to newsletters).</li>
                    <li><strong>Contractual Obligations:</strong> We process your data to fulfill a contract, such as processing your orders or providing customer support.</li>
                    <li><strong>Legal Obligations:</strong> We may process your data to comply with legal obligations, such as tax or reporting laws.</li>
                    <li><strong>Legitimate Interests:</strong> We process your data for our legitimate business interests, such as improving our website’s functionality or preventing fraud, provided these interests do not override your fundamental rights.</li>
                </ul>
            </section>

            <!-- Information Sharing -->
            <section class="policy-section">
                <h2>Information Sharing</h2>
                <p>
                    We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except in the following situations:
                </p>
                <ul>
                    <li><strong>Service Providers:</strong> We may share your data with trusted third-party service providers who assist us in operating our website, conducting our business, or servicing your account, provided that those parties agree to keep this information confidential.</li>
                    <li><strong>Legal Requirements:</strong> We may disclose your information when required to do so by law or in response to valid legal processes, such as a court order, subpoena, or government investigation.</li>
                    <li><strong>Business Transfers:</strong> In the event of a merger, acquisition, or sale of assets, your information may be transferred to the new entity.</li>
                </ul>
            </section>

            <!-- Cookies and Tracking Technologies -->
            <section class="policy-section">
                <h2>Cookies and Tracking Technologies</h2>
                <p>
                    We use cookies, web beacons, and other tracking technologies to enhance your experience on our site. These small files are placed on your device to remember your preferences, login details, and to provide personalized content based on your activity.
                </p>
                <p>
                    You can choose to disable cookies through your browser settings, but doing so may affect the functionality of certain parts of our site.
                </p>
            </section>

            <!-- Third-Party Links -->
            <section class="policy-section">
                <h2>Third-Party Links</h2>
                <p>
                    Our website may contain links to third-party sites, including payment gateways, social media platforms, or external content. Please note that we are not responsible for the privacy practices or the content of these external websites. We encourage you to review the privacy policies of any third-party site you visit.
                </p>
            </section>

            <!-- Data Security -->
            <section class="policy-section">
                <h2>Data Security</h2>
                <p>
                    We implement a variety of security measures to protect your personal information. This includes encryption, secure servers, and regular audits of our systems to ensure compliance with best practices.
                </p>
                <p>
                    However, no method of transmission over the internet or electronic storage is completely secure, so while we strive to protect your data, we cannot guarantee its absolute security.
                </p>
            </section>

            <!-- Data Retention -->
            <section class="policy-section">
                <h2>Data Retention</h2>
                <p>
                    We retain your personal information for as long as necessary to fulfill the purposes for which it was collected, including compliance with legal, regulatory, and reporting obligations.
                </p>
                <p>
                    We take measures to ensure your personal data is securely deleted or anonymized once it is no longer needed.
                </p>
            </section>

            <!-- Your Rights and Choices (GDPR and CCPA) -->
            <section class="policy-section">
                <h2>Your Rights and Choices</h2>
                <p>
                    As a user, you have the right to:
                </p>
                <ul>
                    <li>Access, update, or delete your personal information at any time.</li>
                    <li>Request a copy of the data we hold about you.</li>
                    <li>Opt-out of marketing communications by clicking the unsubscribe link in our emails.</li>
                    <li>Disable cookies or other tracking technologies through your browser settings.</li>
                    <li>Exercise your rights under the GDPR (for EU users) or the CCPA (for California residents), including the right to know what data we collect, the right to request deletion of data, and the right to opt-out of the sale of personal data.</li>
                </ul>
                <p>
                    If you wish to exercise any of these rights, please contact us via the information provided below.
                </p>
            </section>

            <!-- Children's Privacy -->
            <section class="policy-section">
                <h2>Children's Privacy</h2>
                <p>
                    Our website is not directed at children under the age of 13, and we do not knowingly collect personal information from children. If we become aware that we have inadvertently received personal information from a user under the age of 13, we will delete such information from our records.
                </p>
            </section>

            <!-- Changes to This Privacy Policy -->
            <section class="policy-section">
                <h2>Changes to This Privacy Policy</h2>
                <p>
                    We may update this Privacy Policy from time to time to reflect changes in our practices, legal requirements, or enhancements to our website. We will notify you of any significant changes by updating the date at the top of this policy or by sending an email notification.
                </p>
                <p>
                    We encourage you to review this policy periodically to stay informed about how we are protecting your information.
                </p>
            </section>

            <!-- Contact Us -->
            <section class="policy-section">
    <h2>Contact Us</h2>
    <p>
        If you have any questions or concerns about this Privacy Policy, or if you would like to exercise any of your rights, please contact us at:
    </p>
    <p><strong>Email:</strong> <a id="cont" href="mailto:support@allinone.com">support@allinone.com</a></p>
    <p><strong>Phone:</strong> <a id="cont" href="tel:+9745960180">+977 9745960180</a></p>
    <p><strong>Mailing Address:</strong> 1234 Privacy St, Data City, USA</p>

    <!-- Map Embed -->
    <div class="map-container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3168.1234567890!2d-122.1234567890!3d37.1234567890!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808580c0c0c0c0c0%3A0x1234567890!2s1234%20Privacy%20St%2C%20Data%20City%2C%20USA!5e0!3m2!1sen!2s!4v1612345678900" 
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
</section>

        </div>
    </main>

    <!-- Include the footer -->
    <?php include '../components/user_footer.php'; ?>
    <script>
     document.addEventListener('DOMContentLoaded', function () {
    const sections = document.querySelectorAll('.policy-section');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && entry.target.style.animation === '') {
                // Trigger the animation when the section is visible
                entry.target.style.animation = 'fadeInUp 0.8s ease forwards';
            }
        });
    }, { threshold: 0.3 });

    sections.forEach(section => {
        observer.observe(section);
    });
});
    </script>
</body>
</html>
