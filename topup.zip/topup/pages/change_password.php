<?php
// Start the session
session_start();

// Include the header file
include '../components/user_header.php';

// Sample connection to the database (replace with your actual DB credentials)
$servername = "localhost:3307";
$username = "root";
$password = "abishan";
$dbname = "topup";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for messages
$message = '';
$error = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get current and new password from the form
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password']; // Get the confirmation password
    $userId = $_SESSION['user_id']; // Assuming user ID is stored in session

    // Validate new password and confirmation
    if ($newPassword !== $confirmPassword) {
        $error = "New password and confirmation do not match.";
    } else {
        // Fetch the user's current password from the database
        $sql = "SELECT password FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Verify the current password
            if (password_verify($currentPassword, $user['password'])) {
                // Password is correct, proceed to update it
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateSql = "UPDATE users SET password = ? WHERE user_id = ?";
                $updateStmt = $conn->prepare($updateSql);
                $updateStmt->bind_param("si", $hashedNewPassword, $userId);
                
                if ($updateStmt->execute()) {
                    // Set a success message in session and redirect to profile page
                    $_SESSION['profile_update_message'] = "Password changed successfully.";
                    header("Location: profile.php"); // Redirect to profile page
                    exit(); // Ensure no further code is executed after the redirect
                } else {
                    $error = "Error changing password. Please try again.";
                }
                $updateStmt->close();
            } else {
                $error = "Current password is incorrect.";
            }
        } else {
            $error = "User not found.";
        }

        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your main CSS file -->
    <title>Change Password - All In One</title>
    <style>
        main {
            max-width: 400px; /* Maximum width for the form */
            margin: auto; /* Center the form */
            padding: 20px; /* Padding around the form */
            border: 1px solid #ccc; /* Border around the form */
            border-radius: 8px; /* Rounded corners */
            background-color: #f9f9f9; /* Light background color */
        }

        h2 {
            text-align: center; /* Center the heading */
        }

        .form-group {
            margin-bottom: 15px; /* Space between form groups */
        }

        label {
            display: block; /* Label takes full width */
            margin-bottom: 5px; /* Space below the label */
        }

        input[type="password"] {
            width: 100%; /* Full width for inputs */
            padding: 10px; /* Padding inside the input */
            border: 1px solid #ccc; /* Border for the input */
            border-radius: 5px; /* Rounded corners */
        }

        .btn {
            width: 100%; /* Full width for button */
            padding: 10px; /* Padding inside the button */
            color: white; /* Text color */
            background-color: #ff5722; /* Button color */
            border: none; /* Remove border */
            border-radius: 5px; /* Rounded corners */
            font-weight: bold; /* Bold text */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s; /* Smooth color change on hover */
        }

        .btn:hover {
            background-color: #a810ee; /* Change color on hover */
        }

        .success {
            color: green; /* Green for success messages */
            text-align: center; /* Center the success message */
        }

        .error {
            color: red; /* Red for error messages */
            text-align: center; /* Center the error message */
        }
    </style>
</head>
<body>
    <main>
        <h2>Change Password</h2>

        <?php if ($message): ?>
            <p class="success"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form action="change_password.php" method="POST">
            <div class="form-group">
                <label for="current_password">Current Password:</label>
                <input type="password" name="current_password" id="current_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" id="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" required>
            </div>
            <button type="submit" class="btn">Change Password</button>
        </form>
    </main>

    <?php include '../components/user_footer.php'; ?>
</body>
</html>
