<?php
session_start(); // Ensure this is at the top before any HTML output

include '../components/user_header.php';
include '../components/connect.php'; // Include the database connection

// When form is submitted, add to cart
if (isset($_POST['add_to_cart']) || isset($_POST['buy_now'])) {
    $product_id = $_POST['product_id'];
    $diamond_package = $_POST['diamond_package'];

    // Fetch product details from the database
    $query = "SELECT * FROM featured_products WHERE id = $product_id";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
        $price = $product['price']; // Get the price from the fetched product

        // Create cart item array
        $cart_item = [
            'product_id' => $product_id,
            'name' => $product['name'], // Add product name to cart item
            'price' => $price,
            'diamond_package' => $diamond_package,
            'quantity' => 1
        ];

        // If cart session exists, append to it; if not, create new cart
        if (isset($_SESSION['cart'])) {
            $_SESSION['cart'][] = $cart_item;
        } else {
            $_SESSION['cart'] = [$cart_item];
        }

        // Redirect based on which button is clicked
        if (isset($_POST['buy_now'])) {
            // Redirect to checkout page if Buy Now is clicked
            header('Location: /pages/checkout.php');
        } else {
            // Redirect to cart page if Add to Cart is clicked
            header('Location: /pages/cart.php');
        }
        exit();
    } else {
        // Handle case where product is not found
        echo "Product not found.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freefire Diamond Top Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }

        .product-details {
            display: flex;
            flex-direction: row;
            padding: 20px;
        }

        .product-image {
            flex: 1;
            padding-right: 20px;
        }

        .product-image img {
            width: 100%;
            border-radius: 8px;
        }

        .product-info {
            flex: 1;
            padding-left: 20px;
        }

        .product-info h1 {
            font-size: 24px;
            color: #333;
        }

        .price {
            font-size: 28px;
            color: #ff5722;
        }

        .old-price {
            text-decoration: line-through;
            color: grey;
            font-size: 18px;
        }

        .dropdown {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .button {
            background-color: #ff5722;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 10px;
            font-size: 16px;
        }

        .button:hover {
            background-color: #a810ee;
        }

        .buy-now {
            background-color: red;
        }

        .buy-now:hover {
            background-color: #a810ee;
        }
    </style>
    <script>
        function updatePrice() {
            var diamondSelect = document.getElementById("diamond-select");
            var selectedOption = diamondSelect.options[diamondSelect.selectedIndex];
            var originalPrice = selectedOption.getAttribute("data-original-price");
            var discountedPrice = selectedOption.getAttribute("data-discounted-price");

            // Update the price above the button
            document.getElementById("dynamic-price").innerHTML = 
                "₨" + discountedPrice + " <span class='old-price'>Original price was: ₨" + originalPrice + "</span>";
            
            // Update the hidden input for price
            document.getElementById("hidden-price").value = discountedPrice; // Set the hidden price input
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="product-details">
            <!-- Product Image -->
            <div class="product-image">
                <img src="/pages/uploads/ffdaimond.jpg" alt="Freefire Diamond Top Up">
            </div>
            
            <!-- Product Info -->
            <div class="product-info">
                <h1 style="color:#a810ee">Freefire Diamond Top Up (Direct) Via UID</h1>

                <p>Delivery time: 10-60 minutes</p>
                <ul>
                    <li>Platform: Android, iOS</li>
                    <li>Region: Nepal</li>
                    <li>Publisher: Garena</li>
                    <li>Developer: 111Dots Studio</li>
                    <li>Genre: Battle Royale game</li>
                </ul>
                
                <!-- Form to add the item to the cart or buy now -->
                 <!-- Form to add the item to the cart or buy now -->
<form action="" method="POST">
    <input type="hidden" name="product_id" value="1"> <!-- This should be dynamic based on the selected product -->
    <input type="hidden" id="hidden-price" name="price" value="100.00"> <!-- Default value -->
    
    <!-- Dropdown for Diamonds -->
                       <select id="diamond-select" class="dropdown" name="diamond_package" onchange="updatePrice()">
                        <option value="0" data-original-price="0" data-discounted-price="0">Select...</option>
                        <option value="Freefire 115 Diamonds" selected="selected" data-original-price="105.00" data-discounted-price="100.00">Freefire 115 Diamonds</option>
                        <option value="Freefire 230 Diamonds" data-original-price="210.00" data-discounted-price="200.00">Freefire 230 Diamonds</option>
                        <option value="Freefire 355 Diamonds" data-original-price="315.00" data-discounted-price="300.00">Freefire 355 Diamonds</option>
                        <option value="Freefire 480 Diamonds" data-original-price="420.00" data-discounted-price="400.00">Freefire 480 Diamonds</option>
                        <option value="Freefire 610 Diamonds" data-original-price="525.00" data-discounted-price="500.00">Freefire 610 Diamonds</option>
                        <option value="Freefire 725 Diamonds" data-original-price="630.00" data-discounted-price="600.00">Freefire 725 Diamonds</option>
                        <option value="Freefire 850 Diamonds" data-original-price="735.00" data-discounted-price="700.00">Freefire 850 Diamonds</option>
                        <option value="Freefire 950 Diamonds" data-original-price="840.00" data-discounted-price="800.00">Freefire 950 Diamonds</option>
                        <option value="Freefire 1090 Diamonds" data-original-price="945.00" data-discounted-price="900.00">Freefire 1090 Diamonds</option>
                        <option value="Freefire 1240 Diamonds" data-original-price="1050.00" data-discounted-price="1000.00">Freefire 1240 Diamonds</option>
                        <option value="Freefire 2530 Diamonds" data-original-price="2100.00" data-discounted-price="2000.00">Freefire 2530 Diamonds</option>
                        <option value="Freefire 5060 Diamonds" data-original-price="4000.00" data-discounted-price="3400.00">Freefire 5060 Diamonds</option>
                    </select>

    <!-- Dynamic Price -->
    <p id="dynamic-price" class="price">₨100.00</p>

    <!-- Add to Cart Button -->
    <button type="submit" class="button" name="add_to_cart">Add to Cart</button>

    <!-- Buy Now Button -->
    <button type="submit" class="button buy-now" name="buy_now">Buy Now</button>
</form>

            </div>
        </div>
    </div>
</body>
</html>
