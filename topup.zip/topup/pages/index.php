<?php
// Start the session to manage user login
session_start();

// Include the header file
include '../components/user_header.php';

// Database connection details
$servername = "localhost:3307";
$username = "root";
$password = "abishan";
$dbname = "topup";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch featured games from the database
$sql = "SELECT * FROM games"; // Assuming you have a table called 'games'
$result = $conn->query($sql);

// Check if the query was successful
if ($result === false) {
    // Display error message if the query failed
    die("Error in SQL query: " . $conn->error);
}

// Proceed only if there are results
$games = [];
if ($result->num_rows > 0) {
    // Fetch all games into an array
    while ($row = $result->fetch_assoc()) {
        $games[] = $row; // Assuming your table has 'image', 'name', 'price', 'link', 'stars' columns
    }
} else {
    // No games found
    // echo "<p>No games found.</p>";
}

// Fetch featured products for the featured games section
$sqlFeatured = "SELECT * FROM featured_products";
$resultFeatured = $conn->query($sqlFeatured);
$featuredGames = [];

if ($resultFeatured->num_rows > 0) {
    while ($row = $resultFeatured->fetch_assoc()) {
        $featuredGames[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your CSS file -->
    <title>Home Page - All In One</title>
</head>
<body>

    <main>  

        <!-- Hero Section -->
        <div class="hero-section">
            <h1>Welcome to Our Website</h1>
            <p>Explore our latest products and services.</p>
            <a href="shop.php" class="btn">Shop Now</a>
        </div>

        <!-- Slider Section -->
        <div class="slider">
            <div class="slides">
                <div class="slide">
                    <a href="category_freefire.php">
                        <img src="/images/a1.jpg" alt="Slider Game 1">
                        <h2>Free Fire</h2>
                    </a>
                </div>
                <div class="slide">
                    <a href="category_pubg.php">
                        <img src="/images/a2.jpeg" alt="Slider Game 2">
                        <h2>PUBG</h2>
                    </a>
                </div>
                <div class="slide">
                    <a href="category_clashofclan.php">
                        <img src="/images/a3.jpg" alt="Slider Game 3">
                        <h2>Clash of Clan</h2>
                    </a>
                </div>
            </div>
            <div class="slider-buttons">
                <button class="btn" id="prev">❮</button>
                <button class="btn" id="next">❯</button>
            </div>
        </div>

<!-- Featured Games Section -->
<section class="featured-games">
    <h2>Featured Products</h2>
    <div class="product-grid">
        <?php if (!empty($featuredGames)): ?>
            <?php foreach ($featuredGames as $game): ?>
                <div class="product-card">
                    <img src="<?php echo htmlspecialchars($game['image']); ?>" alt="<?php echo htmlspecialchars($game['name']); ?>" class="product-image">
                    <h3><?php echo htmlspecialchars($game['name']); ?></h3>

                    <!-- Display product description -->
                    <p><?php echo htmlspecialchars($game['description']); ?></p>

                    <!-- Display fractional star ratings -->
                    <p class="rating">Rating: 
                        <?php
                        $fullStars = floor($game['stars']); // Full stars
                        $halfStar = ($game['stars'] - $fullStars) >= 0.5; // Check for half star
                        
                        // Display full stars
                        echo str_repeat('⭐', $fullStars);
                        
                        // Display half star if applicable
                        if ($halfStar) {
                            echo '⭐️'; // Add your half-star symbol or HTML entity here, if available.
                        }
                        ?>
                    </p>

                    <p>Price: Rs <?php echo htmlspecialchars($game['price']); ?></p>

                    <!-- Add to Cart button (form for handling the submission) -->
                    <form action="cart.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $game['id']; ?>">
                        <input type="hidden" name="product_name" value="<?php echo $game['name']; ?>">
                        <input type="hidden" name="product_price" value="<?php echo $game['price']; ?>">
                        <button type="submit" name="add_to_cart" class="btn btn-add-to-cart">Add to Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No featured games available at the moment.</p>
        <?php endif; ?>
    </div>
</section>
    </main>

    <?php include '../components/user_footer.php'; ?>

    <script>
        // Slider JavaScript
        let currentIndex = 0;
        const slides = document.querySelector('.slides');
        const totalSlides = document.querySelectorAll('.slide').length;

        document.getElementById('next').addEventListener('click', () => {
            currentIndex = (currentIndex + 1) % totalSlides; // Wrap around
            updateSlidePosition();
        });

        document.getElementById('prev').addEventListener('click', () => {
            currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; // Wrap around
            updateSlidePosition();
        });

        function updateSlidePosition() {
            const offset = -currentIndex * 100;
            slides.style.transform = `translateX(${offset}%)`;
        }

        // Auto slide functionality
        setInterval(() => {
            currentIndex = (currentIndex + 1) % totalSlides; // Wrap around
            updateSlidePosition();
        }, 5000); // Change slide every 5 seconds

    </script>
</body>
</html>
