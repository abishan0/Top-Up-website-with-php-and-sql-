<?php
session_start();
include '../components/connect.php'; // Include your database connection

// Include the header file
include '../components/user_header.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Retrieve the user ID from session

// Handle search by date
$search_date = '';
if (isset($_POST['search_date'])) {
    $search_date = $_POST['search_date'];
    $query = "SELECT * FROM orders WHERE user_id = ? AND DATE(order_date) = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $search_date);
} else {
    $query = "SELECT * FROM orders WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
}

$stmt->execute();
$result = $stmt->get_result();

// Handle individual order deletion
if (isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];
    $delete_query = "DELETE FROM orders WHERE id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("ii", $order_id, $user_id);
    $delete_stmt->execute();
    
    // Redirect to refresh the page
    header('Location: same_page.php'); // Adjust if using another page
    exit();
}

// Handle bulk deletion (delete all orders)
if (isset($_POST['delete_all'])) {
    $delete_all_query = "DELETE FROM orders WHERE user_id = ?";
    $delete_all_stmt = $conn->prepare($delete_all_query);
    $delete_all_stmt->bind_param("i", $user_id);
    $delete_all_stmt->execute();
    
    // Redirect to refresh the page
    header('Location: same_page.php'); // Adjust if using another page
    exit();
}
?>

<!-- Checkout Section Starts -->

<!-- Checkout content or form -->
<!-- Your existing checkout form goes here -->

<!-- Now display the order history below the checkout section -->
<div class="order-history-section">
    <h2>Your Order History</h2>

    <!-- Search by Date -->
    <form method="POST" action="">
        <label for="search_date">Search by Date:</label>
        <input type="date" name="search_date" value="<?php echo htmlspecialchars($search_date); ?>">
        <button type="submit">Search</button>
    </form>

    <!-- Display the Order History -->
    <form method="POST" action="">
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                    <th>Status</th>
                    <th>Player Name</th>
                    <th>UID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($order = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                            <td><?php echo $order['quantity']; ?></td>
                            <td>Rs <?php echo number_format($order['total_price'], 2); ?></td>
                            <td><?php echo date('Y-m-d H:i:s', strtotime($order['order_date'])); ?></td>
                            <td><?php echo htmlspecialchars($order['status']); ?></td>
                            <td><?php echo htmlspecialchars($order['player_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['uid']); ?></td>
                            <td>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <button type="submit" name="delete_order" class="btn btn-delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Button to delete all orders -->
        <button type="submit" name="delete_all" class="btn btn-delete-all">Delete All Orders</button>
    </form>
</div>

<!-- End of order history section -->
<?php include '../components/user_footer.php'; ?>
