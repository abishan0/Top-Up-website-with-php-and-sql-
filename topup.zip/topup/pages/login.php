<?php
// Start session
session_start();

// Database connection details
$host = 'localhost:3307';
$db = 'topup';
$user = 'root';
$pass = 'abishan';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create PDO connection
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

// If the user is already logged in, redirect to home page
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Handle login logic here
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate login credentials using prepared statements
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        if (password_verify($password, $user['password'])) {
            // Login success, set session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['login_success'] = "Login Successfully"; // Set success message
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid email or password";
        }
    } else {
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css">
    <title>Login - All In One</title>
    <style>
        .shake {
            animation: shake 0.5s;
        }
        
        @keyframes shake {
            0% { transform: translate(1px, 0); }
            25% { transform: translate(-1px, 0); }
            50% { transform: translate(1px, 0); }
            75% { transform: translate(-1px, 0); }
            100% { transform: translate(0, 0); }
        }

        .message {
            display: none;
            color: green; /* Success message color */
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (isset($error)) : ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <!-- Success Message -->
        <?php if (isset($_SESSION['register_success'])): ?>
            <div class="message shake" id="success-message">
                <span>&#10004; <?php echo $_SESSION['register_success']; ?></span>
            </div>
            <?php unset($_SESSION['register_success']); // Clear the message ?>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="input-box">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-box">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="input-box">
                <button type="submit">Login</button>
            </div>
        </form>
        <div class="links">
            <a href="forgot_password.php">Forgot Password?</a>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
    
    <?php include '../components/user_footer.php'; ?>

    <script>
        // Fade out effect for the success message
        window.onload = function() {
            const successMessage = document.getElementById('success-message');
            if (successMessage) {
                successMessage.style.display = 'block'; // Show the message
                setTimeout(() => {
                    successMessage.style.transition = 'opacity 1s'; // Fade effect
                    successMessage.style.opacity = '0'; // Fade out
                }, 3000); // Wait for 3 seconds
            }
        }
    </script>
</body>
</html>
