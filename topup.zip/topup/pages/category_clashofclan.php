<?php
// Include the header
include '../components/user_header.php';

// Database connection
include '../components/connect.php';

// Fetch featured products from the Free Fire category
$sql = "SELECT * FROM featured_products WHERE category = 'clashofclan'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free Fire Featured Products</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .category-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 40px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #a810ee;
            text-align: center;
            font-size: 36px;
            margin-bottom: 30px;
        }
        .product-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .product-card {
            width: 23%; /* Adjusted width to fit 4 products in a row */
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s;
            position: relative; /* For positioning the button */
        }
        .product-card:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .product-card img {
            width: 100%;
            height: auto;
        }
        .product-card h3 {
            color: #333;
            text-align: center;
            padding: 10px 0;
            font-size: 20px;
        }
        .product-card p {
            color: #888;
            text-align: center;
            margin: 10px 0;
        }
        .product-card .price {
            font-weight: bold;
            color: #ff5722;
        }
        .product-card .stars {
            text-align: center;
            color: #ff5722;
        }
        .add-to-cart {
            display: block;
            width: 100%;
            padding: 10px;
            text-align: center;
            background-color: #ff5722;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            bottom: 0; /* Position at the bottom of the card */
        }
    </style>
</head>
<body>
    <div class="category-container">
        <h1>Clash of Clan Products</h1>
        <div class="product-grid">
            <?php
            // Check if there are results and output product cards
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="product-card">';
                    echo '<a href="product_details.php?id=' . $row['id'] . '">'; // Link to product details
                    echo '<img src="' . $row['image'] . '" alt="' . $row['name'] . '">'; // Display product image
                    echo '<h3>' . $row['name'] . '</h3>'; // Display product name
                    echo '<p class="price">Rs ' . number_format($row['price'], 2) . '</p>'; // Display product price
                    echo '<div class="stars">⭐ ' . number_format($row['stars'], 1) . ' / 5</div>'; // Display star rating
                    echo '</a>';
                    // Form for adding to cart
                    echo '<form action="cart.php" method="POST">';
                    echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
                    echo '<button type="submit" name="add_to_cart" class="add-to-cart">Add to Cart</button>'; // Submit button
                    echo '</form>';
                    echo '</div>';
                }
            } else {
                echo '<p>No featured products found in this category.</p>'; // Message if no products
            }
            $conn->close(); // Close the database connection
            ?>
        </div>
    </div>
</body>
</html>

<?php
// Include the footer
include '../components/user_footer.php';
?>
