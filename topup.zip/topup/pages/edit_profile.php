<?php
// Start the session
session_start();

// Include the header file
include '../components/user_header.php';

// Sample connection to the database (replace with your actual DB credentials)
$servername = "localhost:3307";
$username = "root";
$password = "abishan";
$dbname = "topup";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for messages
$message = '';
$error = '';

// Fetch user details for the form (assuming user ID is stored in session)
$userId = $_SESSION['user_id']; // Assuming user ID is stored in session

// Fetch the user's current details from the database
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    $error = "User not found.";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get updated profile information from the form
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    
    // Handle file upload
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
        // Directory to save the uploaded file
        $uploadDir = 'uploads/'; // Ensure this folder is writable
        $uploadFile = $uploadDir . basename($_FILES['profile_photo']['name']);
        
        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $uploadFile)) {
            // File uploaded successfully, update profile with new photo
            $photoPath = $uploadFile;
        } else {
            $error = "Error uploading the file.";
        }
    } else {
        // Use the existing photo if no new file was uploaded
        $photoPath = $user['profile_picture']; // Assuming 'profile_picture' is the column in your users table
    }

    // Prepare the SQL update statement
    $updateSql = "UPDATE users SET username = ?, email = ?, phone_number = ?, dob = ?, gender = ?, address = ?, profile_picture = ? WHERE user_id = ?";
    $updateStmt = $conn->prepare($updateSql);

    // Check if the query preparation is successful
    if ($updateStmt === false) {
        die('Error in SQL preparation: ' . $conn->error); // Debugging line
    }
    
    // Bind the parameters (7 strings and 1 integer)
    $updateStmt->bind_param("sssssssi", $username, $email, $phone_number, $dob, $gender, $address, $photoPath, $userId);
    
    if ($updateStmt->execute()) {
        // Set a success message in session and redirect to profile page
        $_SESSION['profile_update_message'] = "Profile updated successfully.";
        header("Location: profile.php"); // Redirect to profile page
        exit(); // Ensure no further code is executed after the redirect
    } else {
        $error = "Error updating profile. Please try again.";
    }
    
    $updateStmt->close();
}

// Close the database connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your main CSS file -->
    <title>Edit Profile - All In One</title>
    <style>
        main {
            max-width: 400px; /* Maximum width for the form */
            margin: auto; /* Center the form */
            padding: 20px; /* Padding around the form */
            border: 1px solid #ccc; /* Border around the form */
            border-radius: 8px; /* Rounded corners */
            background-color: #f9f9f9; /* Light background color */
        }

        h2 {
            text-align: center; /* Center the heading */
        }

        .form-group {
            margin-bottom: 15px; /* Space between form groups */
        }

        label {
            display: block; /* Label takes full width */
            margin-bottom: 5px; /* Space below the label */
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="date"],
        select {
            width: 100%; /* Full width for inputs */
            padding: 10px; /* Padding inside the input */
            border: 1px solid #ccc; /* Border for the input */
            border-radius: 5px; /* Rounded corners */
        }

        .btn {
            width: 100%; /* Full width for button */
            padding: 10px; /* Padding inside the button */
            color: white; /* Text color */
            background-color: #ff5722; /* Button color */
            border: none; /* Remove border */
            border-radius: 5px; /* Rounded corners */
            font-weight: bold; /* Bold text */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s; /* Smooth color change on hover */
        }

        .btn:hover {
            background-color: #a810ee; /* Change color on hover */
        }

        .success {
            color: green; /* Green for success messages */
            text-align: center; /* Center the success message */
        }

        .error {
            color: red; /* Red for error messages */
            text-align: center; /* Center the error message */
        }

        /* Existing styles here */
        .photo-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <main>
        <h2>Edit Profile</h2>

        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form action="edit_profile.php" method="POST" enctype="multipart/form-data"> <!-- Add enctype for file upload -->
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone_number">Phone Number:</label>
                <input type="tel" name="phone_number" id="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>" required>
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" name="dob" id="dob" value="<?php echo htmlspecialchars($user['dob']); ?>" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select name="gender" id="gender" required>
                    <option value="male" <?php if ($user['gender'] == 'male') echo 'selected'; ?>>Male</option>
                    <option value="female" <?php if ($user['gender'] == 'female') echo 'selected'; ?>>Female</option>
                    <option value="other" <?php if ($user['gender'] == 'other') echo 'selected'; ?>>Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" name="address" id="address" value="<?php echo htmlspecialchars($user['address']); ?>" required>
            </div>
            <div class="form-group">
                <label for="profile_photo">Profile Photo:</label>
                <input type="file" name="profile_photo" id="profile_photo">
                <?php if (!empty($user['profile_photo'])): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile Photo" class="photo-preview">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn">Update Profile</button>
        </form>
    </main>

    <?php include '../components/user_footer.php'; ?>
</body>
</html>
