<?php
session_start(); // Start the session to track cart items

// Include the database connection
include '../components/connect.php';

// Redirect to the shop page if the cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: shop.php'); // Adjust the path to your shop page if necessary
    exit(); // Ensure no further code is executed
}

// Calculate total price
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    if (is_array($item)) { // Ensure that $item is an array
        $total_price += $item['price'] * $item['quantity'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ensure user is logged in
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php'); // Redirect to the login page
        exit();
    }

    $user_id = $_SESSION['user_id']; // Retrieve the user ID from session
    $player_name = $_POST['player_name'];
    $uid = $_POST['uid'];

    // Handle image upload
    $upload_dir = '../uploads/'; // Specify the upload directory
    $image = '';

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = basename($_FILES['image']['name']);
        $target_file = $upload_dir . $image_name;

        // Check file type
        $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($image_file_type, $allowed_types)) {
            // Ensure the uploads directory exists and has write permissions
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true); // Create the directory if it doesn't exist
            }

            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Image uploaded successfully
                $image = $target_file; // Save the image path for processing later
            } else {
                echo "Sorry, there was an error uploading your file.";
                exit(); // Stop further execution
            }
        } else {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit();
        }
    }

    // Insert each cart item as an individual order
    foreach ($_SESSION['cart'] as $item) {
        if (is_array($item)) {
            $product_name = $item['name'];
            $quantity = $item['quantity'];
            $item_total_price = $item['price'] * $item['quantity'];

            // Prepare and execute the insert statement (without the image column)
            $query = "INSERT INTO orders (user_id, product_name, quantity, total_price, order_date, status, player_name, uid) 
                      VALUES (?, ?, ?, ?, NOW(), 'Pending', ?, ?)";
            $stmt = $conn->prepare($query);
            
            if (!$stmt) {
                die("SQL Error: " . $conn->error); // Display the SQL error if there is one
            }

            // Use appropriate types for binding
            $stmt->bind_param("isssss", $user_id, $product_name, $quantity, $item_total_price, $player_name, $uid);
            $stmt->execute();
        }
    }

    // Clear the cart after successful order placement
    $_SESSION['cart'] = []; // Or unset($_SESSION['cart']);
    
    // Redirect to a thank you page
    header('Location: order.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - All In One</title>
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your CSS -->
</head>
<body>
    <main>
        <div class="checkout-container">
            <h1>Checkout</h1>
            <div class="checkout-content">
                <div class="cart-summary">
                    <h2>Your Order</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                                <?php if (is_array($item)): ?> <!-- Check if $item is an array -->
                                    <tr>
                                        <td><img src="<?php echo $item['image']; ?>" alt="Product Image"><?php echo $item['name']; ?></td>
                                        <td>Rs <?php echo number_format($item['price'], 2); ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td>Rs <?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p class="total-price">Total: Rs <?php echo number_format($total_price, 2); ?></p>
                </div>

                <div class="user-info">
                    <h2>Your Details</h2>
                    <form action="checkout.php" method="POST" enctype="multipart/form-data"> <!-- Ensure form can handle file uploads -->
                        <label for="player_name">Player Name</label>
                        <input type="text" id="player_name" name="player_name" placeholder="allinone" required>

                        <label for="uid">UID</label>
                        <input type="text" id="uid" name="uid" placeholder="123456789" required>

                        <h3>Payment Method</h3>
                        
                        <label for="esewa_name">Esewa Name</label>
                        <input type="text" id="esewa_name" name="esewa_name" value="Abishan Mainlai" required readonly>

                        <label for="esewa_id">Esewa ID</label>
                        <input type="text" id="esewa_id" name="esewa_id" value="9745960180" required readonly>

                        <label for="khalti_name">Khalti Name</label>
                        <input type="text" id="khalti_name" name="khalti_name" value="Abishan Mainlai" required readonly>

                        <label for="khalti_id">Khalti ID</label>
                        <input type="text" id="khalti_id" name="khalti_id" value="9745960180" required readonly>

                        <label for="bank_name">Bank Name</label>
                        <input type="text" id="bank_name" name="bank_name" value="Sanima Bank" required readonly>

                        <label for="account_holder">Account Holder Name</label>
                        <input type="text" id="account_holder" name="account_holder" value="Abishan Mainlai" required readonly>

                        <label for="bank_branch">Bank Branch</label>
                        <input type="text" id="bank_branch" name="bank_branch" value="Baneshwar Branch" required readonly>

                        <label for="account_number">Account Number</label>
                        <input type="text" id="account_number" name="account_number" value="023011060008974" required readonly>

                        <!-- Image Upload Section -->
                        <label for="image">Upload Image</label>
                        <input type="file" id="image" name="image" accept="image/*" required>

                        <div class="checkout-actions">
                            <button type="submit" name="checkout">Place Order</button>
                            <a href="cart.php" class="btn btn-back">Back to Cart</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
