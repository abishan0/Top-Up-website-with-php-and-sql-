<?php
// Start the session
session_start();

// Include the connection file
include '../components/connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize user input
    $username = $conn->real_escape_string(trim($_POST['username']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $dob = $conn->real_escape_string(trim($_POST['dob']));
    $gender = $conn->real_escape_string(trim($_POST['gender']));
    $phone_number = $conn->real_escape_string(trim($_POST['phone_number']));
    $address = $conn->real_escape_string(trim($_POST['address']));

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Handle the file upload
    $profile_picture = '';
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
        $fileName = uniqid() . '_' . $_FILES['profile_picture']['name']; // Prevent file name conflicts
        $uploadFileDir = './uploads/';
        $dest_path = $uploadFileDir . basename($fileName);

        if (move_uploaded_file($fileTmpPath, $dest_path)) {
            $profile_picture = $dest_path;
        } else {
            echo "Error moving the uploaded file.";
            exit();
        }
    } else {
        echo "No file uploaded or there was an upload error.";
        exit();
    }

    // Prepare and execute the SQL statement to insert user data
    $sql = "INSERT INTO users (username, email, password, dob, gender, profile_picture, phone_number, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("MySQL prepare error: " . $conn->error);
    }

    $stmt->bind_param("ssssssss", $username, $email, $hashed_password, $dob, $gender, $profile_picture, $phone_number, $address);

    if ($stmt->execute()) {
  // Redirect to the verification page or success page
$_SESSION['register_success'] = "Registration successful! Please log in.";
header("Location: login.php");
exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and database connection
    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css"> <!-- Link to your CSS file -->
    <title>Register - All In One</title>
</head>
<body>
    <main>
        <div class="register-container">
            <h2>Register</h2>
            <form action="register.php" method="POST" enctype="multipart/form-data">
                <!-- Username -->
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <!-- Email -->
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <!-- Date of Birth -->
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" required>

                <!-- Gender -->
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>

                <!-- Phone Number -->
                <label for="phone_number">Phone Number:</label>
                <input type="text" id="phone_number" name="phone_number" required>

                <!-- Address -->
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>

                <!-- Profile Picture -->
                <label for="profile_picture">Profile Picture:</label>
                <input type="file" id="profile_picture" name="profile_picture" accept="image/*" required>

                <!-- Password -->
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <!-- Confirm Password -->
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>

                <!-- Register Button -->
                <button id="reg" type="submit">Register</button>
            </form>

            <div class="links">
                <!-- Link to Login Page -->
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </main>
    <!-- Include the footer file -->
    <?php include '../components/user_footer.php'; ?>
</body>
</html>
